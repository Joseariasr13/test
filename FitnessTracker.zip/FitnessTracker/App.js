import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Importa todas las pantallas
import HomeScreen from './src/screens/HomeScreen';
import SelectMuscleScreen from './src/screens/SelectMuscleScreen';
import ExercisesScreen from './src/screens/ExercisesScreen';
import ExerciseDetailScreen from './src/screens/ExerciseDetailScreen';
import HistoryScreen from './src/screens/HistoryScreen';
import StatsScreen from './src/screens/StatsScreen';
import MuscleSelectorScreen from './src/screens/MuscleSelectorScreen';
import RoutinesScreen from './src/screens/RoutinesScreen';
import RoutineDetailScreen from './src/screens/RoutineDetailScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator 
        initialRouteName="Home"
        screenOptions={{
          headerStyle: {
            backgroundColor: '#2196F3',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      >
        <Stack.Screen 
          name="Home" 
          component={HomeScreen} 
          options={{ title: 'Inicio' }}
        />
        <Stack.Screen 
          name="MuscleSelector" 
          component={MuscleSelectorScreen}
          options={{ title: 'Seleccionar Músculo' }}
        />
        <Stack.Screen 
          name="SelectMuscle" 
          component={SelectMuscleScreen} 
          options={{ title: 'Seleccionar Músculo' }}
        />
        <Stack.Screen 
          name="Exercises" 
          component={ExercisesScreen} 
          options={{ title: 'Ejercicios' }}
        />
        <Stack.Screen 
          name="ExerciseDetail" 
          component={ExerciseDetailScreen} 
          options={{ title: 'Detalle del Ejercicio' }}
        />
        <Stack.Screen 
          name="History" 
          component={HistoryScreen} 
          options={{ title: 'Historial' }}
        />
        <Stack.Screen 
          name="Stats" 
          component={StatsScreen} 
          options={{ title: 'Estadísticas' }}
        />
        <Stack.Screen 
          name="Routines" 
          component={RoutinesScreen}
          options={{ title: 'Rutinas' }}
        />
        <Stack.Screen 
          name="RoutineDetail" 
          component={RoutineDetailScreen}
          options={{ title: 'Detalle de Rutina' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}