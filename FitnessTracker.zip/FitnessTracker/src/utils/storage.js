import AsyncStorage from '@react-native-async-storage/async-storage';

const WORKOUTS_KEY = '@workouts';

export const saveWorkout = async (workout) => {
  try {
    // Obtener entrenamientos existentes
    const existingWorkouts = await getWorkouts();
    
    // Añadir el nuevo entrenamiento con fecha
    const newWorkout = {
      ...workout,
      id: Date.now(),
      date: new Date().toISOString(),
    };
    
    // Guardar la lista actualizada
    const updatedWorkouts = [...existingWorkouts, newWorkout];
    await AsyncStorage.setItem(WORKOUTS_KEY, JSON.stringify(updatedWorkouts));
    
    return true;
  } catch (error) {
    console.error('Error saving workout:', error);
    return false;
  }
};

export const getWorkouts = async () => {
  try {
    const workouts = await AsyncStorage.getItem(WORKOUTS_KEY);
    return workouts ? JSON.parse(workouts) : [];
  } catch (error) {
    console.error('Error getting workouts:', error);
    return [];
  }
};