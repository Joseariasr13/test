import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const HomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Gym Tracker</Text>
      <TouchableOpacity 
        style={styles.button}
        onPress={() => navigation.navigate('SelectMuscle')}
      >
        <Text style={styles.buttonText}>Comenzar Entrenamiento</Text>
      </TouchableOpacity>

      <TouchableOpacity 
        style={[styles.button, styles.routinesButton]}
        onPress={() => navigation.navigate('Routines')}
      >
        <Text style={styles.buttonText}>Rutinas</Text>
      </TouchableOpacity>

      <TouchableOpacity 
        style={[styles.button, styles.historyButton]}
        onPress={() => navigation.navigate('History')}
      >
        <Text style={styles.buttonText}>Ver Historial</Text>
      </TouchableOpacity>

      <TouchableOpacity 
        style={[styles.button, styles.statsButton]}
        onPress={() => navigation.navigate('Stats')}
      >
        <Text style={styles.buttonText}>Estadísticas</Text>
      </TouchableOpacity>

      <TouchableOpacity 
        style={[styles.button, styles.mapButton]}
        onPress={() => navigation.navigate('MuscleSelector')}
      >
        <Text style={styles.buttonText}>Mapa Muscular</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 40,
    color: '#2196F3',
  },
  button: {
    backgroundColor: '#2196F3',
    padding: 15,
    borderRadius: 10,
    width: '100%',
    alignItems: 'center',
    marginBottom: 15,
    elevation: 3, // Añadido para dar sombra en Android
    shadowColor: '#000', // Añadido para dar sombra en iOS
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  routinesButton: {
    backgroundColor: '#3F51B5', // Azul índigo para rutinas
  },
  historyButton: {
    backgroundColor: '#4CAF50',
  },
  statsButton: {
    backgroundColor: '#FF9800',
  },
  mapButton: {
    backgroundColor: '#9C27B0',
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default HomeScreen;