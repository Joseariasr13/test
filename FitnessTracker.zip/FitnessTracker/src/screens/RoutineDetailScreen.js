import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity,
  Alert,
  Modal,
  TextInput
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

/*
Estructura esperada de ejercicio:
{
  nombre: string,
  series: number,
  repeticiones: string,
  peso: string,
  descanso: number,
  completed: boolean,
  sets: Array<{
    weight: string,
    reps: string,
    completed: boolean
  }>
}
*/
const RoutineDetailScreen = ({ route, navigation }) => {
  const { routine } = route.params;
  const [activeDay, setActiveDay] = useState(Object.keys(routine.dias)[0]);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingExercise, setEditingExercise] = useState(null);
  const [localRoutine, setLocalRoutine] = useState(routine);
  const [isRoutineActive, setIsRoutineActive] = useState(false);

  useEffect(() => {
    checkActiveRoutine();
  }, []);
  
  const checkActiveRoutine = async () => {
    try {
      const activeRoutineData = await AsyncStorage.getItem('activeRoutine');
      if (activeRoutineData) {
        const routineData = JSON.parse(activeRoutineData);
        const startDate = new Date(routineData.startDate);
        const now = new Date();
        const hoursDiff = (now - startDate) / (1000 * 60 * 60);
        
        if (hoursDiff > 24) {
          await AsyncStorage.removeItem('activeRoutine');
          setIsRoutineActive(false);
        } else {
          setIsRoutineActive(true);
        }
      } else {
        setIsRoutineActive(false);
      }
    } catch (error) {
      console.error('Error checking active routine:', error);
      setIsRoutineActive(false);
    }
  };

  const verifyActiveRoutine = async () => {
    try {
      const activeRoutineData = await AsyncStorage.getItem('activeRoutine');
      if (activeRoutineData) {
        const routineData = JSON.parse(activeRoutineData);
        // Verificar si la rutina tiene más de 24 horas
        const startDate = new Date(routineData.startDate);
        const now = new Date();
        const hoursDiff = (now - startDate) / (1000 * 60 * 60);
        
        if (hoursDiff > 24) {
          // Si han pasado más de 24 horas, eliminar la rutina activa
          await AsyncStorage.removeItem('activeRoutine');
          setIsRoutineActive(false);
          return false;
        }
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error verifying active routine:', error);
      return false;
    }
  };
  const handleEditExercise = (exercise) => {
    setEditingExercise({...exercise});
    setShowEditModal(true);
  };

  const saveExerciseChanges = async () => {
    if (!editingExercise) return;

    try {
      const updatedDias = {...localRoutine.dias};
      updatedDias[activeDay].ejercicios = updatedDias[activeDay].ejercicios.map(ej =>
        ej.nombre === editingExercise.nombre ? editingExercise : ej
      );

      const updatedRoutine = {
        ...localRoutine,
        dias: updatedDias
      };

      setLocalRoutine(updatedRoutine);

      if (!routine.isPredefined) {
        const customRoutines = await AsyncStorage.getItem('customRoutines');
        let routines = customRoutines ? JSON.parse(customRoutines) : [];
        routines = routines.map(r => r.id === routine.id ? updatedRoutine : r);
        await AsyncStorage.setItem('customRoutines', JSON.stringify(routines));
      }

      setShowEditModal(false);
      setEditingExercise(null);
    } catch (error) {
      Alert.alert('Error', 'No se pudieron guardar los cambios');
    }
  };

  const startRoutine = async () => {
    try {
      // Preparar los ejercicios con la estructura correcta
      const exercisesWithSets = localRoutine.dias[activeDay].ejercicios.map(ejercicio => ({
        ...ejercicio,
        muscle: ejercicio.muscle || activeDay, // Aseguramos que tenga un músculo asociado
        completed: false,
        sets: Array(ejercicio.series || 3).fill().map(() => ({
          weight: '',
          reps: '',
          completed: false
        }))
      }));
  
      const routineData = {
        routineId: localRoutine.id,
        routineName: localRoutine.nombre,
        currentDay: activeDay,
        exercises: exercisesWithSets,
        startDate: new Date().toISOString(),
        totalExercises: exercisesWithSets.length,
        currentExerciseIndex: 0
      };
  
      await AsyncStorage.setItem('activeRoutine', JSON.stringify(routineData));
      setIsRoutineActive(true);
  
      // Navegar directamente al primer ejercicio
      if (exercisesWithSets.length > 0) {
        const firstExercise = exercisesWithSets[0];
        navigation.navigate('ExerciseDetail', {
          exercise: firstExercise,
          muscle: firstExercise.muscle || activeDay,
          fromRoutine: true,
          routineData: routineData,
          exerciseIndex: 0,
          totalExercises: exercisesWithSets.length
        });
      } else {
        Alert.alert('Error', 'No hay ejercicios en esta rutina para este día');
      }
    } catch (error) {
      console.error('Error starting routine:', error);
      Alert.alert('Error', 'No se pudo iniciar la rutina');
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <Text style={styles.title}>{localRoutine.nombre}</Text>
          <View style={styles.levelBadge}>
            <Text style={styles.levelText}>{localRoutine.nivel}</Text>
          </View>
          <Text style={styles.description}>{localRoutine.descripcion}</Text>
        </View>

        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          style={styles.daysContainer}
        >
          {Object.keys(localRoutine.dias).map((dia) => (
            <TouchableOpacity
              key={dia}
              style={[
                styles.dayButton,
                activeDay === dia && styles.activeDayButton
              ]}
              onPress={() => setActiveDay(dia)}
            >
              <Text style={[
                styles.dayButtonText,
                activeDay === dia && styles.activeDayButtonText
              ]}>
                {dia}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={styles.dayDetails}>
          <Text style={styles.dayTitle}>{localRoutine.dias[activeDay].nombre}</Text>
          
          {localRoutine.dias[activeDay].ejercicios.map((ejercicio, index) => (
            <TouchableOpacity 
              key={index} 
              style={styles.exerciseItem}
              onPress={() => !routine.isPredefined && handleEditExercise(ejercicio)}
            >
              <View style={styles.exerciseHeader}>
                <Text style={styles.exerciseName}>{ejercicio.nombre}</Text>
                {!routine.isPredefined && (
                  <TouchableOpacity 
                    style={styles.editButton}
                    onPress={() => handleEditExercise(ejercicio)}
                  >
                    <Text style={styles.editButtonText}>Editar</Text>
                  </TouchableOpacity>
                )}
              </View>
              <Text style={styles.exerciseDetails}>
                {ejercicio.series} series x {ejercicio.repeticiones} repeticiones
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>

      <TouchableOpacity 
  style={[
    styles.startButton,
    isRoutineActive && styles.startButtonDisabled
  ]}
  onPress={() => {
    if (isRoutineActive) {
      Alert.alert(
        'Rutina Activa',
        'Ya tienes una rutina en progreso. ¿Deseas cancelarla y comenzar esta nueva rutina?',
        [
          {
            text: 'Cancelar',
            style: 'cancel'
          },
          {
            text: 'Comenzar Nueva',
            onPress: async () => {
              await AsyncStorage.removeItem('activeRoutine');
              startRoutine();
            }
          }
        ]
      );
    } else {
      startRoutine();
    }
  }}
>
  <Text style={styles.startButtonText}>
    {isRoutineActive ? 'Rutina en Progreso' : 'Comenzar Rutina'}
  </Text>
</TouchableOpacity>

      <Modal
        visible={showEditModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowEditModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Editar Ejercicio</Text>
            <Text style={styles.exerciseName}>{editingExercise?.nombre}</Text>
            
            <Text style={styles.inputLabel}>Series:</Text>
            <TextInput
              style={styles.input}
              value={editingExercise?.series.toString()}
              onChangeText={(text) => setEditingExercise({
                ...editingExercise,
                series: parseInt(text) || 0
              })}
              keyboardType="numeric"
              placeholder="Número de series"
            />

            <Text style={styles.inputLabel}>Repeticiones:</Text>
            <TextInput
              style={styles.input}
              value={editingExercise?.repeticiones}
              onChangeText={(text) => setEditingExercise({
                ...editingExercise,
                repeticiones: text
              })}
              placeholder="Rango de repeticiones (ej: 8-12)"
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowEditModal(false)}
              >
                <Text style={styles.modalButtonText}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={saveExerciseChanges}
              >
                <Text style={styles.modalButtonText}>Guardar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  levelBadge: {
    backgroundColor: '#e3f2fd',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
    alignSelf: 'flex-start',
    marginBottom: 8,
  },
  levelText: {
    color: '#1976d2',
    fontSize: 14,
    fontWeight: 'bold',
  },
  description: {
    fontSize: 16,
    color: '#666',
  },
  daysContainer: {
    padding: 10,
    backgroundColor: 'white',
    marginTop: 10,
  },
  dayButton: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    marginHorizontal: 5,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
  },
  activeDayButton: {
    backgroundColor: '#2196F3',
  },
  dayButtonText: {
    fontSize: 16,
    color: '#666',
  },
  activeDayButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  dayDetails: {
    padding: 20,
    backgroundColor: 'white',
    marginTop: 10,
    flex: 1,
  },
  dayTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
  },
  exerciseItem: {
    padding: 15,
    backgroundColor: '#f8f8f8',
    borderRadius: 8,
    marginBottom: 10,
  },
  exerciseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  exerciseName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  exerciseDetails: {
    fontSize: 14,
    color: '#666',
  },
  editButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  editButtonText: {
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
  },
  startButton: {
    backgroundColor: '#4CAF50',
    padding: 15,
    margin: 20,
    borderRadius: 8,
    alignItems: 'center',
  },
  startButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 20,
    width: '90%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  inputLabel: {
    fontSize: 16,
    color: '#333',
    marginBottom: 5,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    padding: 10,
    marginBottom: 15,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  modalButton: {
    flex: 1,
    padding: 12,
    borderRadius: 4,
    marginHorizontal: 5,
  },
  cancelButton: {
    backgroundColor: '#f44336',
  },
  saveButton: {
    backgroundColor: '#4CAF50',
  },
  modalButtonText: {
    color: 'white',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  startButtonDisabled: {
    backgroundColor: '#A5D6A7',
    opacity: 0.8
  },
});

export default RoutineDetailScreen;