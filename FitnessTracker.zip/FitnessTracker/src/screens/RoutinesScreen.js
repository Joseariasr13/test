import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  FlatList, 
  Modal,
  TextInput,
  Alert,
  ScrollView
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const predefinedRoutines = {
  ppl: {
    id: 'ppl',
    nombre: "Push Pull Legs (PPL)",
    descripcion: "Rutina de 6 días dividida en empuje, tirón y piernas",
    nivel: "Intermedio",
    dias: {
      "Día 1 - Push": {
        nombre: "Empuje (Pecho, Hombros, Tríceps)",
        ejercicios: [
          { nombre: "Press de Banca", series: 4, repeticiones: "8-12" },
          { nombre: "Press Militar", series: 3, repeticiones: "8-12" },
          { nombre: "Press Inclinado con Mancuernas", series: 3, repeticiones: "10-12" },
          { nombre: "Elevaciones Laterales", series: 3, repeticiones: "12-15" },
          { nombre: "Extensiones de Tríceps", series: 3, repeticiones: "12-15" }
        ]
      },
      "Día 2 - Pull": {
        nombre: "Tirón (Espalda, Bíceps)",
        ejercicios: [
          { nombre: "Dominadas", series: 4, repeticiones: "8-12" },
          { nombre: "Remo con Barra", series: 3, repeticiones: "8-12" },
          { nombre: "Remo con Mancuerna", series: 3, repeticiones: "10-12" },
          { nombre: "Curl de Bíceps", series: 3, repeticiones: "12-15" }
        ]
      },
      "Día 3 - Legs": {
        nombre: "Piernas",
        ejercicios: [
          { nombre: "Sentadillas", series: 4, repeticiones: "8-12" },
          { nombre: "Peso Muerto", series: 3, repeticiones: "8-12" },
          { nombre: "Extensiones de Cuádriceps", series: 3, repeticiones: "12-15" },
          { nombre: "Curl de Isquiotibiales", series: 3, repeticiones: "12-15" }
        ]
      }
    }
  },
  arnold: {
    id: 'arnold',
    nombre: "Arnold Split",
    descripcion: "Rutina de 6 días inspirada en Arnold Schwarzenegger",
    nivel: "Avanzado",
    dias: {
      "Día 1": {
        nombre: "Pecho y Espalda",
        ejercicios: [
          { nombre: "Press de Banca", series: 4, repeticiones: "8-12" },
          { nombre: "Dominadas", series: 4, repeticiones: "8-12" },
          { nombre: "Press Inclinado", series: 3, repeticiones: "8-12" },
          { nombre: "Remo con Barra", series: 3, repeticiones: "8-12" }
        ]
      },
      "Día 2": {
        nombre: "Hombros y Brazos",
        ejercicios: [
          { nombre: "Press Militar", series: 4, repeticiones: "8-12" },
          { nombre: "Curl de Bíceps", series: 4, repeticiones: "8-12" },
          { nombre: "Extensiones de Tríceps", series: 4, repeticiones: "8-12" }
        ]
      },
      "Día 3": {
        nombre: "Piernas y Abdominales",
        ejercicios: [
          { nombre: "Sentadillas", series: 4, repeticiones: "8-12" },
          { nombre: "Peso Muerto", series: 4, repeticiones: "8-12" },
          { nombre: "Abdominales", series: 3, repeticiones: "15-20" }
        ]
      }
    }
  },
  fullBody: {
    id: 'fullBody',
    nombre: "Full Body",
    descripcion: "Rutina de cuerpo completo 3 días por semana",
    nivel: "Principiante",
    dias: {
      "Día A": {
        nombre: "Full Body A",
        ejercicios: [
          { nombre: "Sentadillas", series: 3, repeticiones: "8-12" },
          { nombre: "Press de Banca", series: 3, repeticiones: "8-12" },
          { nombre: "Remo con Barra", series: 3, repeticiones: "8-12" },
          { nombre: "Press Militar", series: 2, repeticiones: "10-12" }
        ]
      },
      "Día B": {
        nombre: "Full Body B",
        ejercicios: [
          { nombre: "Peso Muerto", series: 3, repeticiones: "8-12" },
          { nombre: "Press Inclinado", series: 3, repeticiones: "8-12" },
          { nombre: "Dominadas", series: 3, repeticiones: "8-12" },
          { nombre: "Curl de Bíceps", series: 2, repeticiones: "10-12" }
        ]
      }
    }
  }
};

const RoutinesScreen = ({ navigation }) => {
  const [routines, setRoutines] = useState([]);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingRoutine, setEditingRoutine] = useState(null);
  const [editingExercise, setEditingExercise] = useState(null);
  const [newRoutine, setNewRoutine] = useState({
    nombre: '',
    descripcion: '',
    nivel: 'Principiante',
    dias: {}
  });

  useEffect(() => {
    loadRoutines();
  }, []);

  const loadRoutines = async () => {
    try {
      const customRoutines = await AsyncStorage.getItem('customRoutines');
      const parsedCustomRoutines = customRoutines ? JSON.parse(customRoutines) : [];
      
      const allRoutines = [
        ...Object.values(predefinedRoutines).map(routine => ({
          ...routine,
          isPredefined: true
        })),
        ...parsedCustomRoutines
      ];
      
      setRoutines(allRoutines);
    } catch (error) {
      console.error('Error loading routines:', error);
    }
  };

  const createNewRoutine = async () => {
    try {
      if (!newRoutine.nombre.trim()) {
        Alert.alert('Error', 'El nombre de la rutina es obligatorio');
        return;
      }

      const newRoutineWithId = {
        ...newRoutine,
        id: Date.now().toString(),
        dias: {
          "Día 1": {
            nombre: "Primer día",
            ejercicios: []
          }
        }
      };

      const customRoutines = await AsyncStorage.getItem('customRoutines');
      const currentRoutines = customRoutines ? JSON.parse(customRoutines) : [];
      const updatedRoutines = [...currentRoutines, newRoutineWithId];
      
      await AsyncStorage.setItem('customRoutines', JSON.stringify(updatedRoutines));
      setRoutines([...Object.values(predefinedRoutines), ...updatedRoutines]);
      setShowCreateModal(false);
      setNewRoutine({
        nombre: '',
        descripcion: '',
        nivel: 'Principiante',
        dias: {}
      });
      
      navigation.navigate('RoutineDetail', { routine: newRoutineWithId });
    } catch (error) {
      Alert.alert('Error', 'No se pudo crear la rutina');
    }
  };

  const handleEditExercise = (exercise) => {
    setEditingExercise(exercise);
    setShowEditModal(true);
  };

  const saveExerciseChanges = async () => {
    if (!editingExercise) return;

    try {
      const updatedRoutines = routines.map(routine => {
        if (routine.id === editingRoutine.id) {
          const updatedDias = { ...routine.dias };
          Object.keys(updatedDias).forEach(dia => {
            updatedDias[dia].ejercicios = updatedDias[dia].ejercicios.map(ej =>
              ej.nombre === editingExercise.nombre ? editingExercise : ej
            );
          });
          return { ...routine, dias: updatedDias };
        }
        return routine;
      });

      setRoutines(updatedRoutines);
      await AsyncStorage.setItem('customRoutines', JSON.stringify(
        updatedRoutines.filter(r => !r.isPredefined)
      ));
      setShowEditModal(false);
      setEditingExercise(null);
    } catch (error) {
      Alert.alert('Error', 'No se pudieron guardar los cambios');
    }
  };

  const renderRoutineItem = ({ item }) => (
    <TouchableOpacity 
      style={styles.routineCard}
      onPress={() => navigation.navigate('RoutineDetail', { routine: item })}
    >
      <View style={styles.routineHeader}>
        <Text style={styles.routineName}>{item.nombre}</Text>
        <View style={styles.levelBadge}>
          <Text style={styles.levelText}>{item.nivel}</Text>
        </View>
      </View>
      <Text style={styles.routineDescription}>{item.descripcion}</Text>
      <Text style={styles.routineDays}>
        {`${Object.keys(item.dias).length} días de entrenamiento`}
      </Text>
      
      {!item.isPredefined && (
        <TouchableOpacity 
          style={styles.editButton}
          onPress={() => {
            setEditingRoutine(item);
            setShowEditModal(true);
          }}
        >
          <Text style={styles.editButtonText}>Editar</Text>
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={routines}
        renderItem={renderRoutineItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
      />

      <TouchableOpacity 
        style={styles.fab}
        onPress={() => setShowCreateModal(true)}
      >
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>

      {/* Modal para editar ejercicios */}
      <Modal
        visible={showEditModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowEditModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Editar Ejercicio</Text>
            
            {editingExercise && (
              <>
                <TextInput
                  style={styles.input}
                  value={editingExercise.series.toString()}
                  onChangeText={(text) => setEditingExercise({
                    ...editingExercise,
                    series: parseInt(text) || 0
                  })}
                  keyboardType="numeric"
                  placeholder="Series"
                />
                <TextInput
                  style={styles.input}
                  value={editingExercise.repeticiones}
                  onChangeText={(text) => setEditingExercise({
                    ...editingExercise,
                    repeticiones: text
                  })}
                  placeholder="Repeticiones (ej: 8-12)"
                />
              </>
            )}

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowEditModal(false)}
              >
                <Text style={styles.modalButtonText}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={saveExerciseChanges}
              >
                <Text style={styles.modalButtonText}>Guardar</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Modal para crear nueva rutina */}
      <Modal
        visible={showCreateModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowCreateModal(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Crear Nueva Rutina</Text>
            
            <TextInput
              style={styles.input}
              placeholder="Nombre de la rutina"
              value={newRoutine.nombre}
              onChangeText={(text) => setNewRoutine({...newRoutine, nombre: text})}
            />
            
            <TextInput
              style={styles.input}
              placeholder="Descripción"
              value={newRoutine.descripcion}
              onChangeText={(text) => setNewRoutine({...newRoutine, descripcion: text})}
              multiline
            />
            
            <View style={styles.pickerContainer}>
              <Text style={styles.pickerLabel}>Nivel:</Text>
              <TouchableOpacity
                style={styles.levelSelector}
                onPress={() => {
                  const levels = ['Principiante', 'Intermedio', 'Avanzado'];
                  const currentIndex = levels.indexOf(newRoutine.nivel);
                  const nextIndex = (currentIndex + 1) % levels.length;
                  setNewRoutine({...newRoutine, nivel: levels[nextIndex]});
                }}
              >
                <Text style={styles.levelSelectorText}>{newRoutine.nivel}</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowCreateModal(false)}
              >
                <Text style={styles.modalButtonText}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={createNewRoutine}
              >
                <Text style={styles.modalButtonText}>Crear</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  listContainer: {
    padding: 16,
  },
  routineCard: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  routineHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  routineName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
  },
  levelBadge: {
    backgroundColor: '#e3f2fd',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    marginLeft: 8,
  },
  levelText: {
    color: '#1976d2',
    fontSize: 12,
    fontWeight: 'bold',
  },
  routineDescription: {
    color: '#666',
    marginBottom: 8,
  },
  routineDays: {
    color: '#2196F3',
    fontSize: 14,
  },
  editButton: {
    backgroundColor: '#2196F3',
    padding: 8,
    borderRadius: 4,
    marginTop: 8,
    alignSelf: 'flex-end',
  },
  editButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 20,
    width: '90%',
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 4,
    padding: 10,
    marginBottom: 15,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  modalButton: {
    flex: 1,
    padding: 12,
    borderRadius: 4,
    marginHorizontal: 5,
  },
  cancelButton: {
    backgroundColor: '#f44336',
  },
  saveButton: {
    backgroundColor: '#4CAF50',
  },
  modalButtonText: {
    color: 'white',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 20,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#2196F3',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  fabText: {
    fontSize: 24,
    color: 'white',
    fontWeight: 'bold',
  },
  pickerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  pickerLabel: {
    fontSize: 16,
    marginRight: 10,
  },
  levelSelector: {
    backgroundColor: '#e3f2fd',
    padding: 8,
    borderRadius: 4,
  },
  levelSelectorText: {
    color: '#1976d2',
    fontWeight: 'bold',
  },
});

export default RoutinesScreen;